<template>
    <div>
        <el-container style="height: 700px; border: 1px solid #eee">
            <el-aside width="200px" style="background-color: rgb(238, 241, 246)">
                <!--        <el-menu :default-openeds="['1', '3']">-->
                <!--          <el-submenu index="1">-->
                <!--            <template slot="title"><i class="el-icon-menu"></i>导航一</template>-->
                <!--              <el-menu-item index="1-1">选项1</el-menu-item>-->
                <!--              <el-menu-item index="1-2">选项2</el-menu-item>-->
                <!--              <el-menu-item index="1-3">选项3</el-menu-item>-->
                <!--          </el-submenu>-->
                <!--        </el-menu>-->
                <el-menu router :default-openeds="['0']">
                    <template v-for="(item, index) in $router.options.routes">
                    <el-submenu  :key="index" v-bind:index="index + ''" v-if="item.show" >
                        <template slot="title"><i class="el-icon-reading"></i>{{item.name}}</template>
                        <el-menu-item v-for="(item01, index01) in item.children" :key='index01' :index="item01.path"
                                      :class="$route.path==item01.path?'is-active':''">{{item01.name}}</el-menu-item>
                        <!--                       获取地址栏路径进行判断 -->
                    </el-submenu>
                    </template>
                </el-menu>
            </el-aside>

            <el-container>
                <el-header style="text-align: right; font-size: 12px;">
                    <h3 style="margin-top:1px;float: left; margin-right: 30px;">欢迎使用!! {{this.$session.get("name")}}</h3>

                            <div v-if="this.$session.get('url') == null">
                                <el-dropdown>
                                    <el-avatar style="margin-top: 10px; margin-right: 50px" src="https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1596625201402&di=cdd78d69cfadb41520bebe1f1de3098e&imgtype=0&src=http%3A%2F%2Fb-ssl.duitang.com%2Fuploads%2Fitem%2F201703%2F20%2F20170320112905_5zhQ3.jpeg"></el-avatar>
                                    <el-dropdown-menu slot="dropdown">
                                        <el-dropdown-item @click.native="modify">修改资料</el-dropdown-item>
                                        <el-dropdown-item @click.native="goout">退出系统</el-dropdown-item>
                                    </el-dropdown-menu>
                                </el-dropdown>
                            </div>
                            <div v-if="this.$session.get('url') != null">
                                <el-dropdown>
                                    <el-avatar style="margin-top: 10px; margin-right: 50px" v-bind:src=this.url></el-avatar>
                                    <el-dropdown-menu slot="dropdown">
                                        <el-dropdown-item @click.native="modify">修改资料</el-dropdown-item>
                                        <el-dropdown-item @click.native="goout">退出系统</el-dropdown-item>
                                    </el-dropdown-menu>
                                </el-dropdown>
                            </div>
                </el-header>

                <el-main>
                    <router-view></router-view>
                </el-main>
            </el-container>
        </el-container>
    </div>

</template>



<style>
    .el-header {
        background-color: #B3C0D1;
        color: #333;
        line-height: 60px;
    }

    .el-aside {
        color: #333;
    }
</style>

<script>
    export default {
        data() {
            return {
                url:''
            }
        },
        methods:{
            goout(){
                sessionStorage.removeItem("name")
                this.$router.replace({
                    path:'/'
                })
            },
            modify(){
                // alert("111")
                this.$router.replace({
                    path:'/modify'
                })
            }

        },
        created(){
            this.url = this.$session.get('url');
        }

    };
</script>


