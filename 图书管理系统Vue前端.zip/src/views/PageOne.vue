<template>
    <div>
        <el-input
                placeholder="请输入书名开始搜索"
                v-model="input"
                clearable
                style="width: 30%; margin-bottom: 20px">
        </el-input>

        <el-button icon="el-icon-search" circle style="margin-left: 20px" @click="search"></el-button>

<!--        <el-table-->
<!--                :data="tableData"-->
<!--                border-->
<!--                style="width: 100%">-->
<!--            <el-table-column-->
<!--                    fixed-->
<!--                    prop="id"-->
<!--                    label="ID"-->
<!--                    width="150">-->
<!--            </el-table-column>-->
<!--            <el-table-column-->
<!--                    prop="name"-->
<!--                    label="书名"-->
<!--                    width="150">-->
<!--            </el-table-column>-->
<!--            <el-table-column-->
<!--                    prop="author"-->
<!--                    label="作者"-->
<!--                    width="150">-->
<!--            </el-table-column>-->
<!--            <el-table-column-->
<!--                    prop="city"-->
<!--                    label="市区"-->
<!--                    width="120">-->
<!--            </el-table-column>-->
<!--            <el-table-column-->
<!--                    prop="address"-->
<!--                    label="地址"-->
<!--                    width="300">-->
<!--            </el-table-column>-->
<!--            <el-table-column-->
<!--                    prop="zip"-->
<!--                    label="邮编"-->
<!--                    width="300">-->
<!--            </el-table-column>-->
<!--            <el-table-column-->
<!--                    fixed="right"-->
<!--                    label="操作"-->
<!--                    width="148">-->
<!--                <template slot-scope="scope">-->
<!--                <el-button type="primary" icon="el-icon-edit" @click="edit(scope.row)"></el-button>-->
<!--                <el-button type="primary" icon="el-icon-delete" @click="del(scope.row)"></el-button>-->
<!--                </template>-->
<!--            </el-table-column>-->
<!--        </el-table>-->

        <el-table
                :data="tableData"
                style="width: 100%">
            <el-table-column type="expand">
                <template slot-scope="props">
                    <el-form label-position="left" inline class="demo-table-expand">
                        <el-form-item label="id" style="width: 50%">
                            <span>{{ props.row.id }}</span>
                        </el-form-item>
                        <el-form-item label="名称" style="width: 50%">
                            <span>{{ props.row.name }}</span>
                        </el-form-item>
                        <el-form-item label="作者" style="width: 50%">
                            <span>{{ props.row.author }}</span>
                        </el-form-item>
                        <el-form-item label="出版社" style="width: 50%">
                            <span>{{ props.row.publish }}</span>
                        </el-form-item>
                        <el-form-item label="页数" style="width: 50%">
                            <span>{{ props.row.pages }}</span>
                        </el-form-item>
                        <el-form-item label="价格" style="width: 50%; border: #333333 2px">
                            <span>{{ props.row.price }}</span>
                        </el-form-item>
                        <el-form-item label="图片" style="width: 50%; border: #333333 2px">
                            <el-image
                                    style="width: 110px; height: 150px; margin-top: 15px"
                                    :src="url"
                                    :fit="fit">
                            </el-image>
                        </el-form-item>




                    </el-form>
                </template>
            </el-table-column>
            <el-table-column
                    label="书本ID"
                    prop="id">
            </el-table-column>
            <el-table-column
                    label="书本名称"
                    prop="name">
            </el-table-column>
            <el-table-column
                    label="书本作者"
                    prop="author">
            </el-table-column>
            <el-table-column
                    fixed="right"
                    label="操作"
                    width="148">
                <template slot-scope="scope">
                <el-button type="primary" size="small" icon="el-icon-edit" @click="edit(scope.row)"></el-button>
                <el-button type="primary" size="small" icon="el-icon-delete" @click="del(scope.row)"></el-button>
                </template>
            </el-table-column>
        </el-table>

<!--        分页组件-->
        <el-pagination
                background
                layout="prev, pager, next"
                :page-size="6"
                :total=this.total
                @current-change="page">
        </el-pagination>

    </div>


</template>

<style>
    .demo-table-expand {
        font-size: 0;
    }
    .demo-table-expand label {
        width: 90px;
        color: #99a9bf;
    }
    .demo-table-expand .el-form-item {
        margin-right: 0;
        margin-bottom: 0;
        width: 50%;
    }
</style>

<script>
    export default {
        methods: {
            search(){
                this.$axios.get('http://localhost:8081/book/getbynamelike?page=1&size=6&name='+this.input,{
                    // params:{orderTypeId:this.orderTypeId}
                }).then(response=>{
                    this.total = response.data.totalElements;
                    this.tableData = response.data.content;
                });
            },
            del(row) {
                console.log(row.id)
                this.$confirm('此操作将永久删除书本《'+ row.name +'》信息, 是否继续?', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    this.$axios.delete('http://localhost:8081/book/deleteById/' + row.id)
                    window.location.reload();

                }).catch(() => {
                    this.$message({
                        type: 'info',
                        message: '已取消删除'
                    });
                });
            },
            edit(row){
                console.log(row);
                this.$router.push({
                    path:'/update',
                    query:{
                        id:row.id
                    }
                })
            },
            page(currentPage){
                this.$axios.get('http://localhost:8081/book/findAll/'+currentPage+'/6',{
                    // params:{orderTypeId:this.orderTypeId}
                }).then(response=>{
                    this.total = response.data.totalElements;
                    this.tableData = response.data.content;
                });
            },

        },

        data() {
            return {
                total:null,
                tableData:"",
                input: '',
                fits: ['fill'],
                url:'https://img3.doubanio.com/view/subject/l/public/s27264181.jpg'
            }
        },
        created(){//组件创建完成时执行该方法。
            this.$axios.get('http://localhost:8081/book/findAll/1/6',{
                // params:{orderTypeId:this.orderTypeId}
            }).then(response=>{
                this.total = response.data.totalElements;
                this.tableData = response.data.content;
            });
            // this.$axios.post('http://139.199.27.251:8080/elm/BusinessController/listBusinessByOrderTypeId',
            //     QS.stringify({orderTypeId:this.orderTypeId})
            // ).then(response=>{
            //     this.businessArr = response.data;
            // }).catch(error=>{
            //     //alert("请重试");
            //     console.log("请稍后重试。");
            // });
        }
    }


</script>
