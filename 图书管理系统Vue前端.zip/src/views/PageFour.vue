<template>
    <div>
        <h1>这是页面四</h1>
    </div>
</template>

<script>
    export default {
        name: "PageFour"
    }
</script>

<style scoped>

</style>