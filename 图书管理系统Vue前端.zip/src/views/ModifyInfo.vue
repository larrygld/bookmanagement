<template>
    <el-form style="width: 50%" :model="ruleForm" :rules="rules" ref="ruleForm" label-width="100px" class="demo-ruleForm">
        <el-form-item label="ID" prop="id">
            <el-input v-model="ruleForm.id" readonly></el-input>
        </el-form-item>
        <el-form-item label="用户名" prop="username">
            <el-input v-model="ruleForm.username" readonly></el-input>
        </el-form-item>
        <el-form-item label="密码" prop="password">
            <el-input v-model="ruleForm.password"></el-input>
        </el-form-item>
        <div div v-if="this.$session.get('url') != null">
            <el-form-item label="头像预览" style="width: 50%; border: #333333 2px">
                <el-image
                        style="width: 120px; height: 150px; margin-top: 15px"
                        :src="ruleForm.img"
                        :fit="fit">
                </el-image>
            </el-form-item>
        </div>
        <el-form-item label="头像路径" prop="img">
            <el-input v-model="ruleForm.img"></el-input>
        </el-form-item>

        <el-form-item>
            <el-button type="primary" @click="submitForm('ruleForm')">立即修改</el-button>
            <el-button @click="resetForm('ruleForm')">重置</el-button>
        </el-form-item>
    </el-form>
</template>

<script>
    export default {
        data() {
            return {
                ruleForm: {
                    id: '',
                    username: '',
                    password: '',
                    img:''
                },
                rules: {
                    password: [
                        { required: true, message: '请输入密码', trigger: 'blur' },
                    ],
                    img: [
                        { required: true, message: '请输入头像url', trigger: 'blur' },
                    ]
                }
            };
        },
        methods: {
            submitForm(formName) {
                this.$refs[formName].validate((valid) => {
                    if (valid) {
                        this.$axios.post('http://localhost:8081/updateuser',this.ruleForm
                        ).then(response=>{
                            // console.log(response)
                            if(response.data == 'success'){
                                this.$message({
                                    showClose: true,
                                    message: '信息修改成功！',
                                    type: 'success'
                                });
                                this.$session.set("url",this.ruleForm.img);
                                // alert(this.ruleForm.img)
                                this.$router.push('/home')
                                window.location.reload();
                            }else{
                                this.$message({
                                    showClose: true,
                                    message: '错了哦，修改失败！',
                                    type: 'error'
                                });
                            }
                        })
                    } else {
                        console.log('error submit!!');
                        return false;
                    }
                });
            },
            resetForm(formName) {
                this.$refs[formName].resetFields();
            }
        },
        created(){
            this.$axios.post('http://localhost:8081/findbyname?username='+this.$session.get("name"),{
                // params:{orderTypeId:this.orderTypeId}
            }).then(response=>{
                console.log(response.data)
                this.ruleForm = response.data;
            });
        }
    }
</script>
