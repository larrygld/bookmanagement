<template>

    <div style="background: #B3C0D1; height: 400px; ">
    <el-row style="margin-top: 100px; padding-top: 80px;">
        <el-col :span="8"><div class="grid-content bg-purple"></div></el-col>
        <el-col :span="8"><div class="grid-content bg-purple-light">

                <el-form style="width: 80%" :model="ruleForm" status-icon :rules="rules" ref="ruleForm" label-width="100px" class="demo-ruleForm">
                    <h3 style="margin-bottom: 30px;margin-left: 65px;text-align: center">欢迎使用Vue前后端分离图书管理系统！</h3>

                    <el-form-item label="用户名" prop="name" style="text-align: center">
                        <el-input v-model.number="ruleForm.name" clearable></el-input>
                    </el-form-item>

                    <el-form-item label="密 码" prop="pass" style="text-align: center">
                        <el-input type="password" v-model="ruleForm.pass" clearable></el-input>
                    </el-form-item>

                    <el-form-item style="margin-top: 38px;margin-left: 38px;">
                        <el-button type="primary" @click="submitForm('ruleForm')">登录</el-button>
                        <el-button @click="resetForm('ruleForm')">重置</el-button>
                    </el-form-item>
                </el-form>

        </div></el-col>
        <el-col :span="8"><div class="grid-content bg-purple"></div></el-col>
    </el-row>
    </div>

</template>

<style>
    .el-row {
        margin-top: 200px;
        margin-bottom: 20px;
    }
    .el-col {
        border-radius: 4px;
    }
    .grid-content {
        border-radius: 4px;
        min-height: 80px;
    }
    .row-bg {
        padding: 10px 0;
        background-color: #f9fafc;
    }
</style>

    <script>
    export default {
        data() {
            var checkName = (rule, value, callback) => {
                if (!value) {
                    return callback(new Error('用户名不能为空'));
                }else {
                    callback();
                }
            };
            var validatePass = (rule, value, callback) => {
                if (value === '') {
                    return callback(new Error('请输入密码'));
                }else {
                    callback();
                }
            };

            return {
                ruleForm: {
                    pass: '',
                    name: ''
                },
                rules: {
                    pass: [
                        { validator: validatePass, trigger: 'blur' }
                    ],
                    name: [
                        { validator: checkName, trigger: 'blur' }
                    ]
                }
            };
        },
        methods: {

            login(){
                // this.$axios.get('http://localhost:8081/book/getbynamelike?page=1&size=6&name='+this.input,{
                //     // params:{orderTypeId:this.orderTypeId}
                // }).then(response=>{
                //     this.total = response.data.totalElements;
                //     this.tableData = response.data.content;
                // });
                this.$router.replace({
                    path:'/home'
                })
            },
            submitForm(formName) {
                this.$refs[formName].validate((valid) => {
                    if (valid) {
                        this.$axios.post('http://localhost:8081/login?username='+this.ruleForm.name+'&password='+this.ruleForm.pass
                        ).then(response=>{
                            // console.log(response)
                            if(response.data.status == 'success'){
                                this.$message({
                                    showClose: true,
                                    message: '恭喜你，登录成功！',
                                    type: 'success'
                                });
                                this.$session.set("name",response.data.name);
                                this.$session.set("url",response.data.url);
                                sessionStorage.setItem("name", response.data.name);

                                this.$router.push('/home')
                            }else{
                                this.$message({
                                    showClose: true,
                                    message: '用户名或密码错误！请重新输入！',
                                    type: 'error'
                                });
                            }
                        })
                    } else {
                        console.log('用户名或密码错误！请重新输入！');
                        return false;
                    }
                });
            },
            resetForm(formName) {
                this.$refs[formName].resetFields();
            }
        }
    }
</script>




