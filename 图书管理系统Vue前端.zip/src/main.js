import Vue from 'vue'
import Home from './views/Home'
import App from './App'
import ModifyInfo from "./views/ModifyInfo";
import Login from "@/views/Login";
import PageOne from "./views/PageOne";
import PageTwo from "./views/PageTwo";
import PageThree from "./views/PageThree";
import VueSession from 'vue-session'
import ElementUI from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css'
import Router from "vue-router"
import axios from 'axios'
Vue.use(ElementUI)
Vue.use(Router)
Vue.use(VueSession)

Vue.config.productionTip = false
Vue.prototype.$axios=axios


//配置路由组件
const routes=[

  {
    path: "/home",
    name:"图书管理",
    show: true,
    component:App,
    children:[
      {
        path:'/pageOne',
        name:"全部图书",
        show:true,
        component:PageOne
      },
      {
        path:'/pageTwo',
        name:"添加图书",
        show:true,
        component:PageTwo
      }

    ]
  },
  {
    path: "/update",
    component:App,
    name:"更新图书",
    show:false,
    redirect:"/pageThree",
    children:[
      {
        path:'/pageThree',
        name:"更新",
        show:true,
        component:PageThree
      },


    ]
  },
  {
    path: "/modify",
    component:App,
    name:"更新资料",
    show:false,
    redirect:"/modifyinfo",
    children:[
      {
        path:'/modifyinfo',
        name:"更新",
        show:true,
        component:ModifyInfo
      },


    ]
  },
  {
    path: "/",
    component:Home,
    name:"管理主页",
    show:false,
    redirect:"/login",
    children:[
      {
        path:'/login',
        name:"登录页",
        show:true,
        component:Login
      },

    ]
  }


]



//创建router实例
const router = new Router({
  mode:"history",   //解决路径中带#号的问题
  routes
});

//通过session配置拦截器
router.beforeEach(function(to,from,next){
  let user = sessionStorage.getItem('name');
  //除了登陆、注册、首页、商家列表、商家食品列表之外，都需要权限验证
  if(!(to.path=='/'||to.path=='/login')){
    if(user==null){
      console.log("111");
      router.push('/login');
      location.reload();
    }
  }
  next();
});



new Vue({
  router,
  render: h => h(Home),
}).$mount('#app')








// // 如何localStorage的token不存在或是空跳转到路由
// router.beforeEach((to, from, next) => {
//   if (to.path === '/') {
//     next();
//   } else {
//     if (this.$session.get('name') != null) {
//       next();
//     } else {
//       next('/');
//     }
//   }
//
// })


